create function st_lineinterpolatepoints(text, double precision) returns airbnb.geometry
    immutable
    parallel safe
    language sql
as
$$ SELECT airbnb.ST_LineInterpolatePoints($1::airbnb.geometry, $2);  $$;

alter function st_lineinterpolatepoints(text, double precision) owner to "user";

