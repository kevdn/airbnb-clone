create function st_dwithin(text, text, double precision) returns boolean
    immutable
    parallel safe
    language sql
as
$$ SELECT airbnb.ST_DWithin($1::airbnb.geometry, $2::airbnb.geometry, $3);  $$;

alter function st_dwithin(text, text, double precision) owner to "user";

