create function st_multipolygonfromtext(text) returns airbnb.geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$SELECT airbnb.ST_MPolyFromText($1)$$;

alter function st_multipolygonfromtext(text) owner to "user";

