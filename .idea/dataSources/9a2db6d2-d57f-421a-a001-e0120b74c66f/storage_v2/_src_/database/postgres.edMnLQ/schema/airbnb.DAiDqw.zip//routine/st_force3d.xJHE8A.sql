create function st_force3d(geom airbnb.geometry, zvalue double precision DEFAULT 0.0) returns airbnb.geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$SELECT airbnb.ST_Force3DZ($1, $2)$$;

comment on function st_force3d(airbnb.geometry, double precision) is 'args: geomA, Zvalue = 0.0 - Force the geometries into XYZ mode. This is an alias for ST_Force3DZ.';

alter function st_force3d(airbnb.geometry, double precision) owner to "user";

