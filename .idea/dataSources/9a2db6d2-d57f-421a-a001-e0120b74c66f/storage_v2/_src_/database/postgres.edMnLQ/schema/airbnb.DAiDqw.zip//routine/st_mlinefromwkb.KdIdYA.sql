create function st_mlinefromwkb(bytea) returns airbnb.geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$
	SELECT CASE WHEN airbnb.geometrytype(airbnb.ST_GeomFromWKB($1)) = 'MULTILINESTRING'
	THEN airbnb.ST_GeomFromWKB($1)
	ELSE NULL END
	$$;

alter function st_mlinefromwkb(bytea) owner to "user";

