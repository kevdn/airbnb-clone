create function st_buffer(text, double precision) returns airbnb.geometry
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT airbnb.ST_Buffer($1::airbnb.geometry, $2);  $$;

alter function st_buffer(text, double precision) owner to "user";

