create function st_longestline(geom1 airbnb.geometry, geom2 airbnb.geometry) returns airbnb.geometry
    immutable
    strict
    parallel safe
    cost 5000
    language sql
as
$$SELECT airbnb._ST_LongestLine(airbnb.ST_ConvexHull($1), airbnb.ST_ConvexHull($2))$$;

comment on function st_longestline(airbnb.geometry, airbnb.geometry) is 'args: g1, g2 - Returns the 2D longest line between two geometries.';

alter function st_longestline(airbnb.geometry, airbnb.geometry) owner to "user";

