create function overlaps_nd(airbnb.geometry, airbnb.gidx) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$SELECT $2 OPERATOR(airbnb.&&&) $1;$$;

alter function overlaps_nd(airbnb.geometry, airbnb.gidx) owner to "user";

