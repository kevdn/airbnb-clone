create function st_area(text) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT airbnb.ST_Area($1::airbnb.geometry);  $$;

alter function st_area(text) owner to "user";

