create function st_multipointfromtext(text) returns airbnb.geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$SELECT airbnb.ST_MPointFromText($1)$$;

alter function st_multipointfromtext(text) owner to "user";

