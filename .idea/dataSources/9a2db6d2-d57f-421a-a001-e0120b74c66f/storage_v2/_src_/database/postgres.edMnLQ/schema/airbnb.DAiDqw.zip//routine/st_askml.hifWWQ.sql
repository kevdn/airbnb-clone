create function st_askml(text) returns text
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$ SELECT airbnb.ST_AsKML($1::airbnb.geometry, 15);  $$;

alter function st_askml(text) owner to "user";

