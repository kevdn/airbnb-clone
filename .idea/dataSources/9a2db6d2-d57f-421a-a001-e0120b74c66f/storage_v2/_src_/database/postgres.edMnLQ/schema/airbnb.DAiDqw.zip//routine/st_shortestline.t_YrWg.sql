create function st_shortestline(text, text) returns airbnb.geometry
    immutable
    parallel safe
    language sql
as
$$ SELECT airbnb.ST_ShortestLine($1::airbnb.geometry, $2::airbnb.geometry);  $$;

alter function st_shortestline(text, text) owner to "user";

