create function st_buffer(text, double precision, text) returns airbnb.geometry
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT airbnb.ST_Buffer($1::airbnb.geometry, $2, $3);  $$;

alter function st_buffer(text, double precision, text) owner to "user";

