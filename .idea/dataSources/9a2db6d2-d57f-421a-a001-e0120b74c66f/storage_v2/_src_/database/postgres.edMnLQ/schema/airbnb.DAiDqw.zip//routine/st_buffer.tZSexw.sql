create function st_buffer(airbnb.geography, double precision, text) returns airbnb.geography
    immutable
    strict
    parallel safe
    language sql
as
$$SELECT airbnb.geography(airbnb.ST_Transform(airbnb.ST_Buffer(airbnb.ST_Transform(airbnb.geometry($1), airbnb._ST_BestSRID($1)), $2, $3), airbnb.ST_SRID($1)))$$;

comment on function st_buffer(airbnb.geography, double precision, text) is 'args: g1, radius_of_buffer, buffer_style_parameters - Computes a geometry covering all points within a given distance from a geometry.';

alter function st_buffer(airbnb.geography, double precision, text) owner to "user";

