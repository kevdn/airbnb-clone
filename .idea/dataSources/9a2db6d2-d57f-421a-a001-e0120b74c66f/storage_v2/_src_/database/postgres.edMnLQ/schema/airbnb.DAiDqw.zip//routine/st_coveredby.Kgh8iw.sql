create function st_coveredby(text, text) returns boolean
    immutable
    parallel safe
    language sql
as
$$ SELECT airbnb.ST_CoveredBy($1::airbnb.geometry, $2::airbnb.geometry);  $$;

alter function st_coveredby(text, text) owner to "user";

