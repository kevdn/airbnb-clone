create function st_astext(text) returns text
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$ SELECT airbnb.ST_AsText($1::airbnb.geometry);  $$;

alter function st_astext(text) owner to "user";

