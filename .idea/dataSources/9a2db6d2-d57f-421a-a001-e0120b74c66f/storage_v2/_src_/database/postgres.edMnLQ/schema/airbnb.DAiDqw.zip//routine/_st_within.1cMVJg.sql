create function _st_within(geom1 airbnb.geometry, geom2 airbnb.geometry) returns boolean
    immutable
    parallel safe
    language sql
as
$$SELECT airbnb._ST_Contains($2,$1)$$;

alter function _st_within(airbnb.geometry, airbnb.geometry) owner to "user";

