create function st_buffer(airbnb.geography, double precision) returns airbnb.geography
    immutable
    strict
    parallel safe
    language sql
as
$$SELECT airbnb.geography(airbnb.ST_Transform(airbnb.ST_Buffer(airbnb.ST_Transform(airbnb.geometry($1), airbnb._ST_BestSRID($1)), $2), airbnb.ST_SRID($1)))$$;

alter function st_buffer(airbnb.geography, double precision) owner to "user";

