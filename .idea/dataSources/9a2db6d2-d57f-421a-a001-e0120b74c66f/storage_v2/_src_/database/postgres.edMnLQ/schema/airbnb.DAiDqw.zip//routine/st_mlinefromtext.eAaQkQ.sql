create function st_mlinefromtext(text, integer) returns airbnb.geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$
	SELECT CASE
	WHEN airbnb.geometrytype(airbnb.ST_GeomFromText($1, $2)) = 'MULTILINESTRING'
	THEN airbnb.ST_GeomFromText($1,$2)
	ELSE NULL END
	$$;

alter function st_mlinefromtext(text, integer) owner to "user";

