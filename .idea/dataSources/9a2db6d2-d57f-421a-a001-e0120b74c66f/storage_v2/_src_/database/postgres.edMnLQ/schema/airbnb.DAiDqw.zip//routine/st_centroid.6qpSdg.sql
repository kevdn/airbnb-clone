create function st_centroid(text) returns airbnb.geometry
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT airbnb.ST_Centroid($1::airbnb.geometry);  $$;

alter function st_centroid(text) owner to "user";

