create function st_multilinestringfromtext(text) returns airbnb.geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$SELECT airbnb.ST_MLineFromText($1)$$;

alter function st_multilinestringfromtext(text) owner to "user";

