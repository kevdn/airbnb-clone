create function st_geomcollfromtext(text) returns airbnb.geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$
	SELECT CASE
	WHEN airbnb.geometrytype(airbnb.ST_GeomFromText($1)) = 'GEOMETRYCOLLECTION'
	THEN airbnb.ST_GeomFromText($1)
	ELSE NULL END
	$$;

alter function st_geomcollfromtext(text) owner to "user";

