create function st_closestpoint(text, text) returns airbnb.geometry
    immutable
    parallel safe
    language sql
as
$$ SELECT airbnb.ST_ClosestPoint($1::airbnb.geometry, $2::airbnb.geometry);  $$;

alter function st_closestpoint(text, text) owner to "user";

