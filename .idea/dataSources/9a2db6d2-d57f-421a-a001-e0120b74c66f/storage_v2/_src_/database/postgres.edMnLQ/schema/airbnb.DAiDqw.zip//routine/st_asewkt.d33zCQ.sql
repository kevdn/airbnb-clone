create function st_asewkt(text) returns text
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$ SELECT airbnb.ST_AsEWKT($1::airbnb.geometry);  $$;

alter function st_asewkt(text) owner to "user";

