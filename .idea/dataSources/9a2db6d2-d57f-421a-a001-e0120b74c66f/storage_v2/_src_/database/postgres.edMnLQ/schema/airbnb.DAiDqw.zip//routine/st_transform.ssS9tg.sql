create function st_transform(geom airbnb.geometry, to_proj text) returns airbnb.geometry
    immutable
    strict
    parallel safe
    cost 5000
    language sql
as
$$SELECT airbnb.postgis_transform_geometry($1, proj4text, $2, 0)
	FROM spatial_ref_sys WHERE srid=airbnb.ST_SRID($1);$$;

comment on function st_transform(airbnb.geometry, text) is 'args: geom, to_proj - Return a new geometry with coordinates transformed to a different spatial reference system.';

alter function st_transform(airbnb.geometry, text) owner to "user";

