create function st_mpolyfromwkb(bytea) returns airbnb.geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
	SELECT CASE WHEN airbnb.geometrytype(airbnb.ST_GeomFromWKB($1)) = 'MULTIPOLYGON'
	THEN airbnb.ST_GeomFromWKB($1)
	ELSE NULL END
	$$;

alter function st_mpolyfromwkb(bytea) owner to "user";

