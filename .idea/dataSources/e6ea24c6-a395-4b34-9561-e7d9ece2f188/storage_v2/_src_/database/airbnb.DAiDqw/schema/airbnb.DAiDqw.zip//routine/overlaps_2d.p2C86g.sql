create function overlaps_2d(airbnb.geometry, airbnb.box2df) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$SELECT $2 OPERATOR(airbnb.&&) $1;$$;

alter function overlaps_2d(airbnb.geometry, airbnb.box2df) owner to "user";

