create function st_forcepolygonccw(airbnb.geometry) returns airbnb.geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$ SELECT airbnb.ST_Reverse(airbnb.ST_ForcePolygonCW($1)) $$;

comment on function st_forcepolygonccw(airbnb.geometry) is 'args: geom - Orients all exterior rings counter-clockwise and all interior rings clockwise.';

alter function st_forcepolygonccw(airbnb.geometry) owner to "user";

