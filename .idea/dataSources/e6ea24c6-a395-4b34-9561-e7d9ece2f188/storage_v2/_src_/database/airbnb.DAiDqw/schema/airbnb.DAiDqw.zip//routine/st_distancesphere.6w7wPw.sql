create function st_distancesphere(geom1 airbnb.geometry, geom2 airbnb.geometry) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$select airbnb.ST_distance( airbnb.geography($1), airbnb.geography($2),false)$$;

alter function st_distancesphere(airbnb.geometry, airbnb.geometry) owner to "user";

