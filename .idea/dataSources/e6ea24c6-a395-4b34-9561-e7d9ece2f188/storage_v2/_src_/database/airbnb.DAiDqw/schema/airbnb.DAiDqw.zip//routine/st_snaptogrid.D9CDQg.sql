create function st_snaptogrid(airbnb.geometry, double precision) returns airbnb.geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$SELECT airbnb.ST_SnapToGrid($1, 0, 0, $2, $2)$$;

comment on function st_snaptogrid(airbnb.geometry, double precision) is 'args: geomA, size - Snap all points of the input geometry to a regular grid.';

alter function st_snaptogrid(airbnb.geometry, double precision) owner to "user";

