create function st_symmetricdifference(geom1 airbnb.geometry, geom2 airbnb.geometry) returns airbnb.geometry
    language sql
as
$$SELECT ST_SymDifference(geom1, geom2, -1.0);$$;

alter function st_symmetricdifference(airbnb.geometry, airbnb.geometry) owner to "user";

