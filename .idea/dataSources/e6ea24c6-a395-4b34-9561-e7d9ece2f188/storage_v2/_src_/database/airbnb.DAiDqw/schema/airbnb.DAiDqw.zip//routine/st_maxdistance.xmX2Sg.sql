create function st_maxdistance(geom1 airbnb.geometry, geom2 airbnb.geometry) returns double precision
    immutable
    strict
    parallel safe
    cost 5000
    language sql
as
$$SELECT airbnb._ST_MaxDistance(airbnb.ST_ConvexHull($1), airbnb.ST_ConvexHull($2))$$;

comment on function st_maxdistance(airbnb.geometry, airbnb.geometry) is 'args: g1, g2 - Returns the 2D largest distance between two geometries in projected units.';

alter function st_maxdistance(airbnb.geometry, airbnb.geometry) owner to "user";

