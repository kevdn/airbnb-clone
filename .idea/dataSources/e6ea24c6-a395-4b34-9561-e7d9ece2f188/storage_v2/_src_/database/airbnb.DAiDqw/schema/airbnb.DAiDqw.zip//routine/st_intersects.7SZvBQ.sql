create function st_intersects(text, text) returns boolean
    immutable
    parallel safe
    language sql
as
$$ SELECT airbnb.ST_Intersects($1::airbnb.geometry, $2::airbnb.geometry);  $$;

alter function st_intersects(text, text) owner to "user";

