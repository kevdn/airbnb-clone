create function st_mlinefromtext(text) returns airbnb.geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$
	SELECT CASE WHEN airbnb.geometrytype(airbnb.ST_GeomFromText($1)) = 'MULTILINESTRING'
	THEN airbnb.ST_GeomFromText($1)
	ELSE NULL END
	$$;

alter function st_mlinefromtext(text) owner to "user";

