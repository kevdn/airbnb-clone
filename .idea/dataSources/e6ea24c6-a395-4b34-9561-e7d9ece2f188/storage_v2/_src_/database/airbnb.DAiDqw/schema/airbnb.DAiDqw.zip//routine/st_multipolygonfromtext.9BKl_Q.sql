create function st_multipolygonfromtext(text, integer) returns airbnb.geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$SELECT airbnb.ST_MPolyFromText($1, $2)$$;

alter function st_multipolygonfromtext(text, integer) owner to "user";

