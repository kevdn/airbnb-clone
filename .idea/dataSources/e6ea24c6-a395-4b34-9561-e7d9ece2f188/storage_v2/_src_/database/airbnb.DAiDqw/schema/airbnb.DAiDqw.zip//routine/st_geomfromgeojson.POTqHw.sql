create function st_geomfromgeojson(json) returns airbnb.geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$SELECT airbnb.ST_GeomFromGeoJson($1::text)$$;

alter function st_geomfromgeojson(json) owner to "user";

