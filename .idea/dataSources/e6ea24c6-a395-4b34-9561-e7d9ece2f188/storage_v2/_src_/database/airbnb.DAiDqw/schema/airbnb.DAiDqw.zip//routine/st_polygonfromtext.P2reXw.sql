create function st_polygonfromtext(text) returns airbnb.geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$SELECT airbnb.ST_PolyFromText($1)$$;

alter function st_polygonfromtext(text) owner to "user";

