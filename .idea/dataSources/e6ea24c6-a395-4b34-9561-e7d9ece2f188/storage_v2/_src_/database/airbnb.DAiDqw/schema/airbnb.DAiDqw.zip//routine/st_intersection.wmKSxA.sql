create function st_intersection(text, text) returns airbnb.geometry
    immutable
    strict
    parallel safe
    cost 5000
    language sql
as
$$ SELECT airbnb.ST_Intersection($1::airbnb.geometry, $2::airbnb.geometry);  $$;

alter function st_intersection(text, text) owner to "user";

