create function st_intersection(airbnb.geography, airbnb.geography) returns airbnb.geography
    immutable
    strict
    parallel safe
    language sql
as
$$SELECT airbnb.geography(airbnb.ST_Transform(airbnb.ST_Intersection(airbnb.ST_Transform(airbnb.geometry($1), airbnb._ST_BestSRID($1, $2)), airbnb.ST_Transform(airbnb.geometry($2), airbnb._ST_BestSRID($1, $2))), airbnb.ST_SRID($1)))$$;

comment on function st_intersection(airbnb.geography, airbnb.geography) is 'args: geogA, geogB - Computes a geometry representing the shared portion of geometries A and B.';

alter function st_intersection(airbnb.geography, airbnb.geography) owner to "user";

