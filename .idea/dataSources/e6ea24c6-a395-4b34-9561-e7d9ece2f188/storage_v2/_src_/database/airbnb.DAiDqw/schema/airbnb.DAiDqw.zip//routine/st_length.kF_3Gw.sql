create function st_length(text) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT airbnb.ST_Length($1::airbnb.geometry);  $$;

alter function st_length(text) owner to "user";

