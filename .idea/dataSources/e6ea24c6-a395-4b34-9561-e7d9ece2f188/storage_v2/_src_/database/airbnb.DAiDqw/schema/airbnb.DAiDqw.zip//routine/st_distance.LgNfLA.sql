create function st_distance(text, text) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT airbnb.ST_Distance($1::airbnb.geometry, $2::airbnb.geometry);  $$;

alter function st_distance(text, text) owner to "user";

