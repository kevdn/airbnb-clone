create function st_rotate(airbnb.geometry, double precision, airbnb.geometry) returns airbnb.geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$SELECT airbnb.ST_Affine($1,  cos($2), -sin($2), 0,  sin($2),  cos($2), 0, 0, 0, 1, airbnb.ST_X($3) - cos($2) * airbnb.ST_X($3) + sin($2) * airbnb.ST_Y($3), airbnb.ST_Y($3) - sin($2) * airbnb.ST_X($3) - cos($2) * airbnb.ST_Y($3), 0)$$;

comment on function st_rotate(airbnb.geometry, double precision, airbnb.geometry) is 'args: geomA, rotRadians, pointOrigin - Rotates a geometry about an origin point.';

alter function st_rotate(airbnb.geometry, double precision, airbnb.geometry) owner to "user";

