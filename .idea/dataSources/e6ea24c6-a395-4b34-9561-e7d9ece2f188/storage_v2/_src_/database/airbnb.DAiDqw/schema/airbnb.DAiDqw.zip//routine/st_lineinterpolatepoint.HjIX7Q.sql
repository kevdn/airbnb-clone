create function st_lineinterpolatepoint(text, double precision) returns airbnb.geometry
    immutable
    parallel safe
    language sql
as
$$ SELECT airbnb.ST_LineInterpolatePoint($1::airbnb.geometry, $2);  $$;

alter function st_lineinterpolatepoint(text, double precision) owner to "user";

