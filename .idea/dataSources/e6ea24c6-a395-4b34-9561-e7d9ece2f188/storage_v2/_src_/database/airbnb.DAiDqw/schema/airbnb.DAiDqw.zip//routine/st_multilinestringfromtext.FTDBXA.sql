create function st_multilinestringfromtext(text, integer) returns airbnb.geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$SELECT airbnb.ST_MLineFromText($1, $2)$$;

alter function st_multilinestringfromtext(text, integer) owner to "user";

